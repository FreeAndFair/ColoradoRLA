-- Retrieve the random seed for the audit.

SELECT seed FROM dos_dashboard
;
