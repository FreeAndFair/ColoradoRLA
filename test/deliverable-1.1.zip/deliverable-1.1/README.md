RLA Tool Deliverable 1.1
========================

This deliverable includes the following:

- a set of screenshots of various parts of the county dashboard
(`screenshots.zip`)
- an interactive version of the county and Department of State 
Admin dashboards, including the audit interface, with a 
pre-populated set of election data (`dashboards.zip`)
- an implementation of the back-end server that can accept uploads of
ballot manifests, cast vote record export files, and audit information, 
and can respond to queries about its data (`corla-server.jar`)
- a static HTML document that allows interaction with the back-end 
server through a web browser running on the same machine as the 
back-end server (`corla-server-test.html`)
- a draft of the formal system specification (`corla_model.pdf`)
- example ballot manifest and cast vote record files 
(`test-files.zip`)
- a draft of *The Colorado RLA Tool Book* (`book.pdf`)
- this README file (`README.md`, `README.html`)


Running the Dashboards
======================

To run the dashboards, you must place their files in the 
document root of a web server. One way to do this is to use the
web server available as part of a standard Python installation,
but any web server will work.

To run the dashboards with Python, unpack the `dashboards.zip` 
file and navigate to the resulting `dashboards` directory. 
Then, run one of the following commands:

- `python -m SimpleHTTPServer` (if you have Python 2.x)
- `python3 -m http.server` (if you have Python 3.x)

Next, connect to `http://localhost:8000/` using a web browser
running on the same machine as the web server (if you run it on
a different web server, you will need to connect to a different
URL depending on your web server's configuration). You will be
presented with a login screen, on which you can currently enter
anything in the username and password fields to log in.

After logging in, you will see a temporary page, which will go 
away when the server and client are integrated and the system 
knows which dashboard you should see based on your credentials.
For now, choose either the Department of State Admin button
or the County Official button.

On the county dashboard, you can navigate the interface and 
start an audit. Uploading of files is currently not functional,
and the audit interface currently uses randomly-generated ballot
data and will continue accepting ballot interpretations as long
as you like.

The Department of State Admin dashboard requires more coordination 
with the server for sensible navigation, so it is less intuitive
at this stage of development. However, you can see an early mock-up
of the root dashboard page, and you can use the "Colorado RLA"
drop-down menu to visit any of three other pages.  Start with the
"Audit" choice in that menu, to step through the pages to set up
the audit. You can later return to visit the detail pages for 
Counties and Contests.

Running the Back-End Server
===========================

To run the back-end server, you must start it in a Java 8 runtime,
which can be downloaded from 
http://www.oracle.com/technetwork/java/javase/downloads/jre8-downloads-2133155.html.
You can start the server in one of two ways:

- double-click the `corla-server.jar` file from a file browser
(on Windows, macOS, and some Linux distributions)
- from a Linux, Windows, or macOS command line, navigate to the 
directory in which you placed `corla-server.jar` and run the 
command `java -jar corla-server.jar`

The second of these will result in log output being displayed to the 
console as the server runs, so you can get a sense of what it is doing.

Once the back-end server is started, you can open a web browser on the
machine where you started it and load the HTML file 
`corla-server-test.html` to upload ballot manifests and cast vote
records, and download the resulting parsed data, from the server.
The provided example ballot manifest and cast vote record files
will work with the server, and it should handle other Dominion cast
vote record CSV export files as well.
